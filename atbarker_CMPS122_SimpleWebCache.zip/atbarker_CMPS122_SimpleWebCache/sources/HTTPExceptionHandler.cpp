#include "HTTPExceptionHandler.h"

HTTPExceptionHandler::HTTPExceptionHandler(){} // Default Constructor

HTTPExceptionHandler::~HTTPExceptionHandler() {} // Desructor

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include "TCPSSLServerSocket.h"


TCPSSLServerSocket::TCPSSLServerSocket (const char * _address, int _port, int _backlog ): TCPServerSocket (_address, _port, _backlog )
{

}
bool TCPSSLServerSocket::initializeSocket ( ) // Initialize server socket
{
        // Create a stream socket and return false on error
        if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) return false;
        // initialize serverAddr
        serverAddr.sin_family = AF_INET;
        serverAddr.sin_port = htons(port);
        if ( address != NULL ) // if server address is not NULL listen on specific interface
        {
            if (strcmp (address,"") !=0 ) serverAddr.sin_addr.s_addr = inet_addr(address);
            else serverAddr.sin_addr.s_addr = INADDR_ANY;
        } //else listen on all interfaces
        else serverAddr.sin_addr.s_addr = INADDR_ANY;
        bzero(&(serverAddr.sin_zero), 8); // initialize last 8 bytes of serverAddr (Bug)
        // Disable the Nagle's algorithm
        int flag = 0;
        int result = setsockopt(sock,
                          IPPROTO_TCP,
                          TCP_NODELAY,
                          (char *) &flag,
                          sizeof(int));
        if ( result < 0 )
        {
	       close (sock);
      	       sock = -1;
       	       return false;
    	}
        // Enable socket reuse option.
         int sock_opt = 1;
         result = setsockopt(sock,
                           SOL_SOCKET,
                           SO_REUSEADDR,
                           (void *)&sock_opt,sizeof (sock_opt));
        if ( result < 0 )
 	{
 		close (sock);
 		sock = -1;
 		return false;
 	}
         // Bind the socket handler to the serverAddr
        if (::bind(sock, (struct sockaddr *)&serverAddr, sizeof(struct sockaddr)) == -1)
        {
                // Close socket and return false if bind failed
		close (sock);
		sock = -1;
		return false;
	}
        // Listen on the socket and configure the connection queue size
        if (listen(sock, backlog) == -1)
        {
		close (sock);
		sock = -1;
		return false;
	}
        return true;
}
//initialize openssl
void init_openssl()
{
    SSL_load_error_strings();
    OpenSSL_add_ssl_algorithms();
    //printf("ssl initialized\n");
}
//Create SSL Context
SSL_CTX * create_ssl_context()
{
    //printf("context created\n");
    const SSL_METHOD * method = TLSv1_2_server_method (); 
    SSL_CTX * ctx = SSL_CTX_new(method);
    if (!ctx)
    {
        // Error and exit
    } 
    return ctx;
}

int passwd_cb(char *buf, int size, int rwflag, void *userdata)
{
    strncpy(buf, (char *)("server"), size);
    buf[size - 1] = '\0';
    return strlen(buf);
    //printf("password handled \n");
}

//configure the SSL context
void configure_context (SSL_CTX * ctx)
{
    if (SSL_CTX_use_certificate_file(ctx,"/home/debian/ca/intermediate/atbarker.cmps122.ucsc.cert.pem",SSL_FILETYPE_PEM) < 0 )
    {
        perror("problem cert");
        //printf("problem with cert\n");
    }
    
    SSL_CTX_set_default_passwd_cb(ctx,passwd_cb);
    //printf("password set\n");
    
    // passwd_cb is a callback function that return the password
    if (SSL_CTX_use_PrivateKey_file(ctx,"/home/debian/ca/intermediate/atbarker.cmps122.ucsc.key.pem",SSL_FILETYPE_PEM) < 0 )
    {
        perror("problem key");
        //printf("problem with key\n");
    }
    //printf("context configured\n");
}

TCPSocket * TCPSSLServerSocket::getConnection (int timeoutSec, int timeoutMilli,int readBufferSize,int writeBufferSize )
{
    //initialize the openssl thing
    init_openssl();
    //create and configure the context
    SSL_CTX * ctx = create_ssl_context();
    configure_context(ctx);
    
    //struct sockaddr_in clientAddr;
    //socklen_t sin_size = sizeof(clientAddr);
    //int client_sock = accept (server_sock,(struct sockaddr *) &clientAddr,& sin_size);
    
    
    socklen_t sin_size = sizeof(clientAddr);//= sizeof(struct sockaddr_in);
    //may just be socklen_t sin_size ;
    int client_sock = 0;
    //printf("not accepted yet\n");
    if (timeoutSec==0 && timeoutMilli == 0 )// Blocking mode
    {
        // Wait for connection indefinitely
        client_sock = accept(sock, (struct sockaddr *) &clientAddr,& sin_size);
        //printf("accepted socket connection\n");

    }
    else { // Set up time out timeval and file descriptors set
        fd_set fds; 
        struct timeval tv;
        tv.tv_sec = timeoutSec;
	tv.tv_usec = timeoutMilli;
	FD_ZERO(&fds);
	FD_SET(sock, &fds);
        // wait on activity on the socket for a timeout
	select(sock+1, &fds, NULL, NULL, &tv);
	if (FD_ISSET(sock, &fds)) // if sock is changed 
	{
            // call accept on sock to get the pending connection
	    client_sock = accept(sock, (struct sockaddr *)&clientAddr,&sin_size);
            //printf("accepted socket connection (with timeval and file descriptors)");
	}
    }
    
    
    SSL * ssl = SSL_new(ctx);
    const long flags = SSL_OP_NO_SSLv2 |
                       SSL_OP_NO_SSLv3 |
                       SSL_OP_NO_COMPRESSION;
                       SSL_CTX_set_options(ctx,flags);
    SSL_set_fd(ssl,client_sock);
    //printf("ssl object created\n");
    
    if (SSL_accept(ssl) > 0){
        
    }
    
    
    //pass in this boolean so we use the right parts of TCPsocket
    bool sslon = true;
    if ( client_sock < 1 ) // if newsock is less than one then erroro
    {   // Print the error and return NULL
        perror("ERROR on accept");
        return NULL;
    }
    else{ // Else instantiate a TCPSocket object and return a pointer to it 
        TCPSocket * tcpSocket = new TCPSocket(client_sock,(char *)inet_ntoa(clientAddr.sin_addr),clientAddr.sin_port,readBufferSize,writeBufferSize, sslon, ssl);
        //printf("socket created\n");
        return tcpSocket;
    }
    // If we are here then we return NULL
    return NULL;
}

//cleanup all the ssl stuff
void cleanup_ssl()
{
    EVP_cleanup();
}

//destructor
TCPSSLServerSocket::~TCPSSLServerSocket ( ) // Destructor
{
    cleanup_ssl();
    shutdown (sock,SHUT_RDWR);  // Shutdown the server read/write channels
    close (sock);              // Close socket descriptor
    if ( address != NULL ) free (address); // free the address buffer
}


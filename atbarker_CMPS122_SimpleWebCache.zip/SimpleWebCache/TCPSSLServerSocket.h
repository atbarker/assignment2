/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   TCPSSLServerSocket.h
 * Author: debian
 *
 * Created on May 10, 2017, 11:19 AM
 */

#ifndef TCPSSLSERVERSOCKET_H
#define TCPSSLSERVERSOCKET_H
#include "includes.h"
#include "TCPSocket.h"
#include "TCPServerSocket.h"

class TCPSSLServerSocket : TCPServerSocket {
    
    private:
        
    public:
        TCPSSLServerSocket (const char * _address, int _port, int _backlog );
        bool initializeSocket (); // Initailize server socket
        TCPSocket * getConnection (int timeoutSec=0, int timeoutMilli=0,int readBufferSize=10*1024*1024,int writeBufferSize=10*1024*1024);
        ~TCPSSLServerSocket ( );
};


#endif /* TCPSSLSERVERSOCKET_H */


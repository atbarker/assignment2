/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include "TCPSSLServerSocket.h"
TCPSSLServerSocket::TCPSSLServerSocket (const char * _address, int _port, int _backlog ):TCPServerSocket (const char * _address, int _port, int _backlog )
{

}
//initialize openssl
void init_openssl()
{
    SSL_load_error_strings();
    OpenSSL_add_ssl_algorithms();
}
//Create SSL Context
SSL_CTX * create_ssl_context()
{
    SSL_METHOD * method = TLSv1_2_server_method (); 
    SSL_CTX * ctx = SSL_CTX_new(method);
    if (!ctx)
    {
        // Error and exit
    } 
    return ctx;
}

//configure the SSL context
void configure_context (SSL_CTX * ctx)
{
    if (SSL_CTX_use_certificate_file(ctx,”cert.pem”,SSL_FILETYPE_PEM) < 0 )
    {
        // Error and exit
    }
    SSL_CTX_set_default_password_cb(ctx,passwd_cb);
    // passwd_cb is a callback function that return the password
    if (SSL_CTX_use_PrivateKey_file(ctx,”key.pem”,SSL_FILETYPE_PEM) < 0 )
    {
        // Error and exit
    }
}

TCPSocket * TCPServerSocket::getConnection (int timeoutSec, int timeoutMilli,int readBufferSize,int writeBufferSize )
{
    //initialize the openssl thing
    init_openssl();
    //create and configure the context
    SSL_CTX * ctx = create_ssl_context();
    configure_context(ctx);
    
    //struct sockaddr_in clientAddr;
    //socklen_t sin_size = sizeof(clientAddr);
    //int client_sock = accept (server_sock,(struct sockaddr *) &clientAddr,& sin_size);
    
    
    socklen_t sin_size = sizeof(clientAddr);//= sizeof(struct sockaddr_in);
    //may just be socklen_t sin_size ;
    int client_sock = 0;
    if (timeoutSec==0 && timeoutMilli == 0 )// Blocking mode
    {
        // Wait for connection indefinitely
        client_sock = accept(sock, (struct sockaddr *)&clientAddr,&sin_size);

    }
    else { // Set up time out timeval and file descriptors set
        fd_set fds; 
        struct timeval tv;
        tv.tv_sec = timeoutSec;
	tv.tv_usec = timeoutMilli;
	FD_ZERO(&fds);
	FD_SET(sock, &fds);
        // wait on activity on the socket for a timeout
	select(sock+1, &fds, NULL, NULL, &tv);
	if (FD_ISSET(sock, &fds)) // if sock is changed 
	{
            // call accept on sock to get the pending connection
	    client_sock = accept(sock, (struct sockaddr *)&clientAddr,&sin_size);
	}
    }
    
    
    SSL * ssl = SSL_new(ctx);
    const long flags = SSL_OP_NO_SSLv2 |
                       SSL_OP_NO_SSLv3 |
                       SSL_OP_NO_COMPRESSION;
                       SSL_CTX_set_options(ctx,flags);
    SSL_set_fd(ssl,client_sock);
    
    
    //pass in this boolean so we use the right parts of TCPsocket
    bool sslon = true;
    if ( newsock < 1 ) // if newsock is less than one then erroro
    {   // Print the error and return NULL
        perror("ERROR on accept");
        return NULL;
    }
    else{ // Else instantiate a TCPSocket object and return a pointer to it 
        TCPSocket * tcpSocket = new TCPSocket(newsock,(char *)inet_ntoa(clientAddr.sin_addr),clientAddr.sin_port,readBufferSize,writeBufferSize, sslon, ssl);
        return tcpSocket;
    }
    // If we are here then we return NULL
    return NULL;
}

//cleanup all the ssl stuff
void cleanup_ssl()
{
    EVP_cleanup();
}

//destructor
TCPServerSocket::~TCPServerSocket ( ) // Destructor
{
    cleanup_ssl();
    shutdown (sock,SHUT_RDWR);  // Shutdown the server read/write channels
    close (sock);              // Close socket descriptor
    if ( address != NULL ) free (address); // free the address buffer
}
